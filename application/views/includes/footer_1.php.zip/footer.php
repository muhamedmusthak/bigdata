<div class="footer_section">
	<div class="wrapper">
		<div class="row between-md ">
			<div class="col-xs-12 col-md-3"> <a href="/"><img src="<?php echo base_url();?>application/images/footer-logo.png" alt="Footer Logo"  id="footerLogo"></a>
				<div class="footerSnippt">
					<p>Our training values every second and we handle with varied range of creative, technical, and knowledgable persons at our brand location in Bogota, Colombia
					</p>
				</div>

			</div>
			<div class="col-xs-12 col-md-8">
				<div class="box">
					<div class="row between-xs">
						<div class="col-xs-6 col-sm-3 col-md-4 lineBlock">
				<div class="smTitle">BDIH</div>
				<ul>
					<li><a href="<?php echo base_url('BigdatasiteController/about_us');?>">About us</a></li>
					<li><a href="<?php echo base_url('BigdatasiteController/global-opportunities');?>">Global opportunity</a></li>
					<li><a href="<?php echo base_url('BigdatasiteController/why_us');?>">Why BDIHub</a></li>
					<li><a href="<?php echo base_url('BigdatasiteController/corporate_solutions');?>">Corporate Solutions</a></li>
				</ul>
			</div>
			<div class="col-xs-5 col-sm-3 col-md-4 lineBlock">
				<div class="smTitle">Explore</div>
				<ul>
<!--					<li>Case studies</li>-->
					<li><a href="<?php echo base_url('BigdatasiteController/privacy_policy');?>">Privacy Policy</a></li>
				</ul>
			</div>
			<div class="col-xs-6 col-sm-3 col-md-4 lineBlock">
				<div class="smTitle">Learn</div>
				<ul>
					<li><a href="<?php echo base_url('BigdatasiteController/training_program');?>">Training Program</a></li>
					<li><a href="<?php echo base_url('BigdatasiteController/contact_us');?>">Contact</a></li>
					<li><a href="<?php echo base_url('BigdatasiteController/global_opportunities_new');?>">Job opportunities</a></li>
<!--					<li>Article</li>-->
				</ul>
			</div>
<!--
			<div class="col-xs-6 col-sm-3 col-md-3 lineBlock">
				<div class="smTitle">Learning Center</div>
				<ul>
					<li>Log in</li>
				</ul>
			</div>
-->
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="footerCopy">
		<div class="wrapper">
			&copy; 2017 big data innovation hub. All rights has reserved
		</div>
	</div>
</div>


<div id="AssModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <!-- <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button> -->
           <h3 id="myModalLabel">Questions</h3>
           <h3 id="thankyou">Thank you for taking Online Assessment !</h3>
           <h3 id="batchSched">Batch Schedule</h3>
           <h3 id="timeSched">Time Schedule</h3>
        </div>
        <div class="modal-body" id="myWizard">
          
        <!--  <div class="progress">
           <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="1" aria-valuemin="1" aria-valuemax="10" style="width: 20%;">
             Question 1 
           </div>
         </div> -->
        
         <!-- <div class="navbar">
         </div> -->
         <div class="tab-content">
            <div class="tab-pane fade in active" id="step1">
               
              <div class="well"> 
                
                  <label>Question 1</label>
              		
                  <br>
                  <p>What expertise do you desire to acquire ?<p>
		        	<input class='q3_option' name='q1_option' onchange="radiocall('#step2')" id="1" type='radio'/> Big Data<br>
		            <input class='q3_option' name='q1_option' onchange="radiocall('#step2')" id="1" type='radio'/> Data Science<br>
		            <input class='q3_option' name='q1_option' onchange="radiocall('#step2')" id="1" type='radio'/> Both<br>
              </div>
              <a class="nextButtonbtn btn btn-success " href="#step2" data-toggle="tab" data-step="2">Next</a>
              <!-- <a class="btn btn-default next" href="#step2">Continue</a> -->
            </div>
            <div class="tab-pane fade" id="step2">
               <div class="well"> 
                  <label>Question 2</label>
                  <p>Do you have a wokring knowledge of any relational database ?<p>
		        	<input class='q3_option' name='q2_option' onchange="radiocall('#step3')" type='radio'/> Yes<br>
		            <input class='q3_option' name='q2_option' onchange="radiocall('#step3')" type='radio'/> No<br>
		            
                  <br>
                
               </div>
                <a class="btn btn-success " href="#step1" data-toggle="tab" data-step="2">Previous</a>
               <a class="btn btn-success " href="#step3" data-toggle="tab" data-step="3">Next</a>
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
            </div>
            <div class="tab-pane fade" id="step3">
              <div class="well"> 
              		<label>Question 3</label>
                  <p>What does commodity Hardware in Hadoop world mean?<p>
		        	<input class='q3_option' name='q3_option' onchange="radiocall('#step4')" type='radio' />  Very cheap hardware<br>
		            <input class='q3_option' name='q3_option' onchange="radiocall('#step4')" type='radio' /> Industry standard hardware<br>
		            <input class='q3_option' name='q3_option' onchange="radiocall('#step4')" type='radio' /> Discarded hardware<br>


              </div>
               <a class="btn btn-success " href="#step2" data-toggle="tab" data-step="2">Previous</a>
               <a class="nextButtonbtn btn btn-success " href="#step4" data-toggle="tab" data-step="4">Next</a>
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
            </div>
            <div class="tab-pane fade" id="step4">
              <div class="well"> 
              		<label>Question 4</label>
                  <p> Which of the following are NOT big data problem(s)?<p>
		        	<input class='q3_option' name='q4_option' onchange="radiocall('#step5')" type='radio'/> Parsing 5 MB XML file every 5 minutes<br>
		            <input class='q3_option' name='q4_option' onchange="radiocall('#step5')" type='radio' /> Processing IPL tweet sentiments<br>
		            <input class='q3_option' name='q4_option' onchange="radiocall('#step5')" type='radio' /> Processing online bank transactions<br>
              </div>
               <a class="btn btn-success " href="#step3" data-toggle="tab" data-step="3">Previous</a>
               <a class="nextButtonbtn btn btn-success " href="#step5" data-toggle="tab" data-step="5">Next</a>
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
            </div>
            <div class="tab-pane fade" id="step5">
              <div class="well"> 
              		<label>Question 5</label>
                  <p>What does “Velocity” in Big Data mean?<p>
		        	<input class='q3_option' name='q5_option' onchange="radiocall('#step6')" type='radio' /> Speed of input data generation<br>
		            <input class='q3_option' name='q5_option' onchange="radiocall('#step6')" type='radio' /> Speed of individual machine processors<br>
		            <input class='q3_option' name='q5_option' onchange="radiocall('#step6')" type='radio' /> Speed of ONLY storing data<br>
              </div>
               <a class="btn btn-success " href="#step4" data-toggle="tab" data-step="4">Previous</a>
               <a class="nextButtonbtn btn btn-success " href="#step6" data-toggle="tab" data-step="6">Next</a>
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
            </div>
            <div class="tab-pane fade" id="step6">
              <div class="well"> 
              		<label>Question 6</label>
                 <p>The term Big Data first originated from:<p>
		        	<input class='q3_option' name='q6_option' onchange="radiocall('#step7')" type='radio' /> Stock Markets Domain<br>
		            <input class='q3_option' name='q6_option' onchange="radiocall('#step7')" type='radio' /> Banking and Finance Domain<br>
		            <input class='q3_option' name='q6_option' onchange="radiocall('#step7')" type='radio' /> Genomics and Astronomy Domain<br>
              </div>
               <a class="btn btn-success " href="#step5" data-toggle="tab" data-step="5">Previous</a>
               <a class="nextButtonbtn btn btn-success " href="#step7" data-toggle="tab" data-step="7">Next</a>
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
            </div>
            <div class="tab-pane fade" id="step7">
              <div class="well"> 
              		<label>Question 7</label>
                 <p>Which of the following Batch Processing instance is NOT an example of ( D)BigData Batch Processing<p>
		        	<input class='q3_option' name='q7_option' onchange="radiocall('#step8')" type='radio' /> Processing 10 GB sales data every 6 hours<br>
		            <input class='q3_option' name='q7_option' onchange="radiocall('#step8')" type='radio' /> Processing flights sensor data<br>
		            <input class='q3_option' name='q7_option' type='radio' onchange="radiocall('#step8')" /> Web crawling app<br>
              </div>
               <a class="btn btn-success " href="#step6" data-toggle="tab" data-step="6">Previous</a>
               <a class="nextButtonbtn btn btn-success " href="#step8" data-toggle="tab" data-step="8">Next</a>
              </div>

               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
            
            <div class="tab-pane fade" id="step8">
              <div class="well"> 
              		<label>Question 8</label>
                  <p>Sliding window operations typically fall in the category (C ) of<p>
		        	<input class='q3_option' name='q8_option' onchange="radiocall('#step9')" type='radio'  /> OLTP Transactions<br>
		            <input class='q3_option' name='q8_option' type='radio' onchange="radiocall('#step9')"/> Big Data Batch Processing<br>
		            <input class='q3_option' name='q8_option' type='radio' onchange="radiocall('#step9')"/> Big Data Real Time Processing<br>
              </div>
               <a class="btn btn-success " href="#step7" data-toggle="tab" data-step="7">Previous</a>
               <a class="nextButtonbtn btn btn-success " href="#step9" data-toggle="tab" data-step="9">Next</a>
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
            </div>
            <div class="tab-pane fade" id="step9">
              <div class="well"> 
              		<label>Question 9</label>
                  <p>Do you have a wokring knowledge of any relational database ?<p>
		        	<input class='q3_option' name='q9_option' type='radio' onchange="radiocall('#step10')" /> Yes<br>
		            <input class='q3_option' name='q9_option' type='radio' onchange="radiocall('#step10')"/> No<br>
              </div>
               <a class="btn btn-success " href="#step8" data-toggle="tab" data-step="8">Previous</a>
               <a class="nextButtonbtn btn btn-success " href="#step10" data-toggle="tab" data-step="10">Next</a>
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
            </div>
            <div class="tab-pane fade" id="step10">
              <div class="well"> 
              		<label>Question 10</label>
                  <p>Which of the following are the core components of Hadoop? <p>
		        	<input class='q3_option' name='q10_option' type='radio' /> HDFS<br>
		            <input class='q3_option' name='q10_option' type='radio' /> Map Reduce<br>
		            <input class='q3_option' name='q10_option' type='radio' /> HBase<br>
              </div>
               <a class="btn btn-success " href="#step9" data-toggle="tab" data-step="9">Previous</a>
               <!-- <a class="btn btn-success first" href="#">Start over</a> -->
            </div>
              <div class="tab-pane fade" id="stepSuccess">
              <div class="well"> 
                  <!-- <label>Thank you for Taking our Online Assessment.</label> -->
                 <h3>You are Eligible to take this Course. Please choose batch timing.</h3>
              </div>
              </div>
               <div class="tab-pane fade" id="scheduler">
              <div class="well"> 
                <label>Batch's</label><br>
                 <input class='q3_option' name='q9_option' type='radio' onchange="radiocall('#scheduler1')" /> Weakdays Batchs( Monday to Friday )<br>
                <input class='q3_option' name='q9_option' type='radio' onchange="radiocall('#scheduler2')"/> Weakend Batch( Saturday and Sunday )<br>
                 <a style="display: none" class="nextButtonbtn btn btn-success " href="#scheduler" data-toggle="tab" data-step="13">Next</a>
              </div>
              </div>
               <div class="tab-pane fade" id="scheduler1">
              <div class="well"> 
                 <label>Batch timing</label><br>
                 <input class='q3_option' name='q9_option' type='radio' onchange="radiocall('#payment1')" />Morning 9 am to Noon 2 pm<br>
                <input class='q3_option' name='q9_option' type='radio' onchange="radiocall('#payment1')"/> Evening 6.30 to 9.30 pm<br>
                 <a style="display: none" class="nextButtonbtn btn btn-success " href="#scheduler1" data-toggle="tab" data-step="13">Next</a>
              </div>
                <a class="btn btn-success " href="#scheduler" data-toggle="tab" data-step="9">Previous</a>
              </div>
               <div class="tab-pane fade" id="scheduler2">
              <div class="well"> 
                <label>Batch timing</label><br>
                 <input class='q3_option' name='q9_option' type='radio' onchange="radiocall('#payment1')" />Morning  9 am to Evening 6 pm <br>
                 <a style="display: none" class="nextButtonbtn btn btn-success " href="#scheduler2" data-toggle="tab" data-step="13">Next</a>
              </div>
                 <a class="btn btn-success " href="#scheduler" data-toggle="tab" data-step="9">Previous</a>
              </div>
               <div class="tab-pane fade" id="payment1">
              <div class="well"> 
                <h4>Thank You For Choosing Schedule. Kindly Verify your registred mail address and Proceed to Payment.<br>By Click the link on your email Account.</h4>
                 <a style="display: none" class="nextButtonbtn btn btn-success " href="#payment1" data-toggle="tab" data-step="13">Next</a>
              </div>
               <a href="#" style="font-size: 15px;padding: 10px 10px;text-decoration: none; " id="close_model" data-dismiss="modal" class="btn btn-danger">Close</a>
              </div>
           </div>
        </div>
        <div class="modal-footer">
          <!-- <button class="btn" data-dismiss="modal" aria-hidden="true">Close</button> -->
      <button class="btn btn-primary" id="submit" href="#stepSuccess" data-toggle="tab" data-step="11" onclick="call_classtiming()" >submit</button>
          <button class="btn btn-primary" id="courseDetails" href="#scheduler" data-toggle="tab" data-step="12" onclick="scheduler()">Choose batch timing</button>
        </div>
      </div>`
    </div>
  </div>

<div class="modal fade" id="myModal" role="dialog" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog">
      <form name="contactform" method="post" id="contact_form" enctype="multipart/form-data"  >
      <div class="modal-content">
        <div class="modal-header" >
          <button type="button" class="close enroll_close" data-dismiss="modal">&times;</button>
          <div class="pull-left">
         		<h4 id="head1" class="head1"></h4>
         	    <h4 id="head2" class="head2 hide" style="margin-left: 230px;font-size: 20px;">Thank You!</h4>
              
       	 </div>
        </div>
        <div class="modal-body" >
        <div class="contentBlock" style="font-size: 15px;padding-left: 5%" id="enroll_form">
		<div class="wrapper800" >
	
		<div class="row" >
			<div class="col-xs-12 col-md-7">
			<div id="form-container">
			
        <div class="row">
        <div class="form-group col-md-3">
                <label class="control-label" for="salutation" style="font-size: 15px;">Salutation&nbsp;&nbsp;</label>
        <select class="form-control" name="salutation" id="salutation">
          <option value="Mr." selected="selected">Mr.</option>
          <option value="Mrs.">Mrs.</option>
          <option value="Ms.">Ms.</option>
          <option value="Dr.">Dr.</option>
        </select>
        </div>
      </div>
			<div class="row">
				<input type="hidden" id="course" class="head1" name="course">
				<!-- <input type="hidden" id="" class="head1 course" name="course" value="Assocciate-Big Data">
				<input type="hidden" id="" class="head2 course hide" name="course" value="Assocciate-Data Science"> -->
				<div class="form-group col-md-6">
					<label class="control-label">First Name<span style="color:red">*</span></label>
					<input type="text" class="form-control" name="first_name" id="first_name" size="40" placeholder="First Name">
				</div>
				<div class="form-group col-md-6">
					<label class="control-label">Last Name<span style="color:red">*</span></label>
					<input type="text" class="form-control" name="last_name" id="last_name" size="40" placeholder="Last Name" style=" background-position: 10px -54px;">
				</div>
			</div>
			<div class="row">
				<div class="form-group col-md-6">
					<label class="control-label">Telephone<span style="color:red">*</span></label>
					<input type="text" class="form-control" id="phone_num" name="phone_num" size="40" placeholder="Telephone" style=" background-position: 10px -88px;">
				</div>
				<div class="form-group col-md-6">
					<label class="control-label">Company</label>
					<input type="text" class="form-control" name="company" id="company" size="40" placeholder="Company" style=" background-position: 8px -184px;">
				</div>
			</div>
      <div class="row">
        <div class="form-group col-md-6">
         <label class="control-label">Email<span style="color:red">*</span></label>
          <input type="text" class="form-control" id="email" name="email" size="40" placeholder="Email" style=" background-position: 10px -121px;">
        </div>
      </div>
			
			</div>
			</div>
		</div>

			</div>
		</div>
			<div class="contentBlock hide" id="assessment" style="font-size: 15px;padding-left: 50px;">
			    <div class="wrapper800" >
			     <h3>Thank You! You have registered Successfully. Proceed to Online Assessment</h3>
           <p></p>
			    </div>
	   		</div>
        
        
        <div class="modal-footer">
          <a href="#" style="font-size: 17px;padding: 10px 10px;text-decoration: none; " data-dismiss="modal" class="enroll_close">Close</a>
             <button class="btn1 call_enroll" name="enroll" id="call_enroll">Enroll Now</button>
             <button class="btn1 hide call_Assessment" name="" id="call_Assessment" onclick="call_Assessment()">Take Assessment</button>
        </div>
      </div>
    </div>
    </form>
</div>
</div>

<!-- Path finder Model window starts -->
<style type="text/css">
.pathbase{
    border-top: 2px solid #3E8Acc;
    padding-top: 15px;
    
}
.pathfinderbtn{
  border: 2px solid #3E8Acc;
  background-color: white;
  border-radius: 15px;
  min-width: 150px;
  min-height: 40px;

}
</style>
<div id="PathfinderModel" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header" style="background-color: #3E8Acc;">
        <button type="button" style="color: white;" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h2 style="padding-left: 40%;color: white;">Path Finder</h2>
      </div>
      <div class="modal-body"   id="myWizard">
        <div class="tab-content">
          <div class="tab-pane fade in active" style="padding-bottom: 40px;padding-top: 40px;" id="path1">
           <div class="">
              <center>
                <h3>Need help to choose a course? </h3>
                <p>Let us help you choose your path. Answer a few questions to find a learning path that suits you best.</p>
                <a class="pathfinderbtn btn" href="#main" data-toggle="tab" data-step="2">Let's go</a>
              </center>            
              <!-- <a class="btn btn-default next" href="#step2">Continue</a> -->
            </div> 
          </div>
        <div class="tab-pane fade" style="padding-bottom: 40px;padding-top: 40px;" id="main">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate')" type='radio'/> Associate<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner')" type='radio'/> Practitioner<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Specialist')" type='radio'/> Specialist<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Advanced')" type='radio'/> Advanced Specialist<br>
              <br>
            </div>
          </div>
        <!--  <div class="pathbase"> -->
            <a class="btn btn-success " style="display: none;" href="#path1" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success" style="display: none;" href="#path3" data-toggle="tab" data-step="3">Next</a>
          <!-- </div>  --> 
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>
        <div class="tab-pane fade" id="Associate">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate1')" type='radio'/> Associate1<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate2')" type='radio'/> Associate2<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate3')" type='radio'/> Associate3<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate4')" type='radio'/> Associate4<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#main" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " style="display: none;" href="#Associate1" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Associate2" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Associate3" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Associate4" data-toggle="tab" data-step="4">Next</a>
            

          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>
        <div class="tab-pane fade" id="Associate1">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate11')" type='radio'/> Associate11<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate12')" type='radio'/> Associate12<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate13')" type='radio'/> Associate13<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate14')" type='radio'/> Associate14<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Associate" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " style="display: none;" href="#Associate11" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Associate12" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Associate13" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Associate14" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>
        <div class="tab-pane fade" id="Associate11">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate111')" type='radio'/> Associate111<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate112')" type='radio'/> Associate112<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate113')" type='radio'/> Associate113<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate114')" type='radio'/> Associate114<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Associate1" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " href="#path4" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>
        <div class="tab-pane fade" id="Associate12">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate121')" type='radio'/> Associate121<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate122')" type='radio'/> Associate122<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate123')" type='radio'/> Associate123<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate124')" type='radio'/> Associate124<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Associate1" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " href="#path4" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>
           <div class="tab-pane fade" id="Associate13">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate131')" type='radio'/> Associate131<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate132')" type='radio'/> Associate132<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate133')" type='radio'/> Associate133<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate134')" type='radio'/> Associate134<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Associate1" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " href="#path4" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>  
           <div class="tab-pane fade" id="Associate14">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate141')" type='radio'/> Associate141<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate142')" type='radio'/> Associate142<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate143')" type='radio'/> Associate143<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate144')" type='radio'/> Associate144<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Associate1" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " href="#path4" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>   
          <div class="tab-pane fade" id="Associate2">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate21')" type='radio'/> Associate21<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate22')" type='radio'/> Associate22<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate23')" type='radio'/> Associate23<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate24')" type='radio'/> Associate24<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Associate" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " style="display: none;" href="#Associate21" data-toggle="tab" data-step="4">Next</a>
             <a class="btn btn-success " style="display: none;" href="#Associate22" data-toggle="tab" data-step="4">Next</a>
              <a class="btn btn-success " style="display: none;" href="#Associate23" data-toggle="tab" data-step="4">Next</a>
               <a class="btn btn-success " style="display: none;" href="#Associate24" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div> 
        <div class="tab-pane fade" id="Associate21">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate211')" type='radio'/> Associate211<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate212')" type='radio'/> Associate212<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate213')" type='radio'/> Associate213<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate214')" type='radio'/> Associate214<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Associate2" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " href="#path4" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>
        <div class="tab-pane fade" id="Associate22">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate221')" type='radio'/> Associate221<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate222')" type='radio'/> Associate222<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate223')" type='radio'/> Associate223<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate224')" type='radio'/> Associate224<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Associate2" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " href="#path4" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>
           <div class="tab-pane fade" id="Associate23">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate231')" type='radio'/> Associate231<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate232')" type='radio'/> Associate232<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate233')" type='radio'/> Associate233<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate234')" type='radio'/> Associate234<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Associate1" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " href="#path4" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>  
           <div class="tab-pane fade" id="Associate24">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate241')" type='radio'/> Associate241<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate242')" type='radio'/> Associate242<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate243')" type='radio'/> Associate243<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate244')" type='radio'/> Associate244<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Associate1" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " href="#path4" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>  
          <div class="tab-pane fade" id="Associate3">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate31')" type='radio'/> Associate31<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate32')" type='radio'/> Associate32<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate33')" type='radio'/> Associate33<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate34')" type='radio'/> Associate34<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Associate" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " style="display: none;" href="#Associate31" data-toggle="tab" data-step="4">Next</a>
             <a class="btn btn-success " style="display: none;" href="#Associate32" data-toggle="tab" data-step="4">Next</a>
              <a class="btn btn-success " style="display: none;" href="#Associate33" data-toggle="tab" data-step="4">Next</a>
               <a class="btn btn-success " style="display: none;" href="#Associate34" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>
           <div class="tab-pane fade" id="Associate31">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate311')" type='radio'/> Associate311<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate312')" type='radio'/> Associate312<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate313')" type='radio'/> Associate313<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate314')" type='radio'/> Associate314<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Associate3" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " href="#path4" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>
        <div class="tab-pane fade" id="Associate32">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate321')" type='radio'/> Associate321<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate322')" type='radio'/> Associate322<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate323')" type='radio'/> Associate323<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate324')" type='radio'/> Associate324<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Associate3" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " href="#path4" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>
           <div class="tab-pane fade" id="Associate33">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate331')" type='radio'/> Associate331<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate332')" type='radio'/> Associate332<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate333')" type='radio'/> Associate333<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate334')" type='radio'/> Associate334<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Associate3" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " href="#path4" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>  
           <div class="tab-pane fade" id="Associate34">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate341')" type='radio'/> Associate341<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate342')" type='radio'/> Associate342<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate343')" type='radio'/> Associate343<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate344')" type='radio'/> Associate344<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Associate3" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " href="#path4" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>  
        <div class="tab-pane fade" id="Associate4">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate41')" type='radio'/> Associate41<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate42')" type='radio'/> Associate42<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate43')" type='radio'/> Associate43<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate44')" type='radio'/> Associate44<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success" href="#Associate" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success" style="display: none;" href="#Associate41" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success" style="display: none;" href="#Associate42" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success" style="display: none;" href="#Associate43" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success" style="display: none;" href="#Associate44" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>
                     <div class="tab-pane fade" id="Associate41">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate411')" type='radio'/> Associate411<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate412')" type='radio'/> Associate412<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate413')" type='radio'/> Associate413<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate414')" type='radio'/> Associate414<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Associate4" data-toggle="tab" data-step="2">Previous</a>
           <!--  <a class="btn btn-success " href="#path4" data-toggle="tab" data-step="4">Next</a> -->
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>
        <div class="tab-pane fade" id="Associate42">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate421')" type='radio'/> Associate421<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate422')" type='radio'/> Associate422<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate423')" type='radio'/> Associate423<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate424')" type='radio'/> Associate424<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Associate4" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " href="#path4" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>
           <div class="tab-pane fade" id="Associate43">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate431')" type='radio'/> Associate431<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate432')" type='radio'/> Associate432<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate433')" type='radio'/> Associate433<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate434')" type='radio'/> Associate434<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Associate4" data-toggle="tab" data-step="2">Previous</a>
           <!--  <a class="btn btn-success " href="#path4" data-toggle="tab" data-step="4">Next</a> -->
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>  
           <div class="tab-pane fade" id="Associate44">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate441')" type='radio'/> Associate441<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate442')" type='radio'/> Associate442<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate443')" type='radio'/> Associate443<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Associate444')" type='radio'/> Associate444<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Associate3" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " href="#path4" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>
            <div class="tab-pane fade" id="Practitioner">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner1')" type='radio'/> Practitioner1<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner2')" type='radio'/> Practitioner2<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner3')" type='radio'/> Practitioner3<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner4')" type='radio'/> Practitioner4<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#main" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " style="display: none;" href="#Practitioner1" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Practitioner2" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Practitioner3" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Practitioner4" data-toggle="tab" data-step="4">Next</a>
            

          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>
        <div class="tab-pane fade" id="Practitioner1">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner11')" type='radio'/> Practitioner11<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner12')" type='radio'/> Practitioner12<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner13')" type='radio'/> Practitioner13<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner14')" type='radio'/> Practitioner14<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Practitioner" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " style="display: none;" href="#Practitioner11" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Practitioner12" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Practitioner13" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Practitioner14" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>
        <div class="tab-pane fade" id="Practitioner11">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner111')" type='radio'/> Practitioner111<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner112')" type='radio'/> Practitioner112<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner113')" type='radio'/> Practitioner113<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner114')" type='radio'/> Practitioner114<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Practitioner1" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " href="#path4" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>
        <div class="tab-pane fade" id="Practitioner12">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner121')" type='radio'/> Practitioner121<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner122')" type='radio'/> Practitioner122<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner123')" type='radio'/> Practitioner123<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner124')" type='radio'/> Practitioner124<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Practitioner1" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " href="#path4" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>
           <div class="tab-pane fade" id="Practitioner13">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner131')" type='radio'/> Practitioner131<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner132')" type='radio'/> Practitioner132<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner133')" type='radio'/> Practitioner133<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner134')" type='radio'/> Practitioner134<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Practitioner1" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " href="#path4" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>  
           <div class="tab-pane fade" id="Practitioner14">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner141')" type='radio'/> Practitioner141<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner142')" type='radio'/> Practitioner142<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner143')" type='radio'/> Practitioner143<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner144')" type='radio'/> Practitioner144<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Practitioner1" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " href="#path4" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>   
          <div class="tab-pane fade" id="Practitioner2">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner21')" type='radio'/> Practitioner21<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner22')" type='radio'/> Practitioner22<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner23')" type='radio'/> Practitioner23<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner24')" type='radio'/> Practitioner24<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Practitioner" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " style="display: none;" href="#Practitioner21" data-toggle="tab" data-step="4">Next</a>
             <a class="btn btn-success " style="display: none;" href="#Practitioner22" data-toggle="tab" data-step="4">Next</a>
              <a class="btn btn-success " style="display: none;" href="#Practitioner23" data-toggle="tab" data-step="4">Next</a>
               <a class="btn btn-success " style="display: none;" href="#Practitioner24" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div> 
        <div class="tab-pane fade" id="Practitioner21">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner211')" type='radio'/> Practitioner211<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner212')" type='radio'/> Practitioner212<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner213')" type='radio'/> Practitioner213<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner214')" type='radio'/> Practitioner214<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Practitioner2" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " href="#path4" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>
        <div class="tab-pane fade" id="Practitioner22">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner221')" type='radio'/> Practitioner221<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner222')" type='radio'/> Practitioner222<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner223')" type='radio'/> Practitioner223<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner224')" type='radio'/> Practitioner224<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Practitioner2" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " href="#path4" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>
           <div class="tab-pane fade" id="Practitioner23">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner231')" type='radio'/> Practitioner231<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner232')" type='radio'/> Practitioner232<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner233')" type='radio'/> Practitioner233<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner234')" type='radio'/> Practitioner234<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Practitioner2" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " href="#path4" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>  
           <div class="tab-pane fade" id="Associate24">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner241')" type='radio'/> Practitioner241<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner242')" type='radio'/> Practitioner242<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner243')" type='radio'/> Practitioner243<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner244')" type='radio'/> Practitioner244<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Practitioner2" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " href="#path4" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>  
          <div class="tab-pane fade" id="Practitioner3">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner31')" type='radio'/> Practitioner31<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner32')" type='radio'/> Practitioner32<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner33')" type='radio'/> Practitioner33<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner34')" type='radio'/> Practitioner34<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Practitioner" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " style="display: none;" href="#Practitioner31" data-toggle="tab" data-step="4">Next</a>
             <a class="btn btn-success " style="display: none;" href="#Practitioner32" data-toggle="tab" data-step="4">Next</a>
              <a class="btn btn-success " style="display: none;" href="#Practitioner33" data-toggle="tab" data-step="4">Next</a>
               <a class="btn btn-success " style="display: none;" href="#Practitioner34" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>
           <div class="tab-pane fade" id="Practitioner31">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner311')" type='radio'/> Practitioner311<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner312')" type='radio'/> Practitioner312<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner313')" type='radio'/> Practitioner313<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner314')" type='radio'/> Practitioner314<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Practitioner3" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " href="#path4" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>
        <div class="tab-pane fade" id="Practitioner32">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner321')" type='radio'/> Practitioner321<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner322')" type='radio'/> Practitioner322<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner323')" type='radio'/> Practitioner323<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner324')" type='radio'/> Practitioner324<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Practitioner3" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " href="#path4" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>
           <div class="tab-pane fade" id="Practitioner33">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner331')" type='radio'/> Practitioner331<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner332')" type='radio'/> Practitioner332<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner333')" type='radio'/> Practitioner333<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner334')" type='radio'/> Practitioner334<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Practitioner3" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " href="#path4" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>  
           <div class="tab-pane fade" id="Practitioner34">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner341')" type='radio'/> Practitioner341<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner342')" type='radio'/> Practitioner342<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner343')" type='radio'/> Practitioner343<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner344')" type='radio'/> Practitioner344<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Practitioner3" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " href="#path4" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>  
        <div class="tab-pane fade" id="Practitioner4">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner41')" type='radio'/> Practitioner41<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner42')" type='radio'/> Practitioner42<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner43')" type='radio'/> Practitioner43<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner44')" type='radio'/> Practitioner44<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success" href="#Practitioner" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success" style="display: none;" href="#Practitioner41" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success" style="display: none;" href="#Practitioner42" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success" style="display: none;" href="#Practitioner43" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success" style="display: none;" href="#Associate44" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>
                     <div class="tab-pane fade" id="Practitioner41">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner411')" type='radio'/> Practitioner411<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner412')" type='radio'/> Practitioner412<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner413')" type='radio'/> Practitioner413<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner414')" type='radio'/> Practitioner414<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Practitioner4" data-toggle="tab" data-step="2">Previous</a>
           <!--  <a class="btn btn-success " href="#path4" data-toggle="tab" data-step="4">Next</a> -->
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>
        <div class="tab-pane fade" id="Practitioner42">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner421')" type='radio'/> Practitioner421<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner422')" type='radio'/> Practitioner422<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner423')" type='radio'/> Practitioner423<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner424')" type='radio'/> Practitioner424<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Practitioner4" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " href="#path4" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>
           <div class="tab-pane fade" id="Practitioner43">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner431')" type='radio'/> Practitioner431<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner432')" type='radio'/> Practitioner432<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner433')" type='radio'/> Practitioner433<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner434')" type='radio'/> Practitioner434<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Practitioner4" data-toggle="tab" data-step="2">Previous</a>
           <!--  <a class="btn btn-success " href="#path4" data-toggle="tab" data-step="4">Next</a> -->
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>  
           <div class="tab-pane fade" id="Practitioner44">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner441')" type='radio'/> Practitioner441<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner442')" type='radio'/> Practitioner442<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner443')" type='radio'/> Practitioner443<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Practitioner444')" type='radio'/> Practitioner444<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Practitioner3" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " href="#path4" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div> 
         <div class="tab-pane fade" id="Specialist">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Specialist1')" type='radio'/> Specialist1<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Specialist2')" type='radio'/> Specialist2<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Specialist3')" type='radio'/> Specialist3<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Specialist4')" type='radio'/> Specialist4<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#main" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " style="display: none;" href="#Specialist1" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Specialist2" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Specialist3" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Specialist4" data-toggle="tab" data-step="4">Next</a>
            

          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>
            <div class="tab-pane fade" id="Specialist1">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Specialist11')" type='radio'/> Specialist11<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Specialist12')" type='radio'/> Specialist12<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Specialist13')" type='radio'/> Specialist13<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Specialist14')" type='radio'/> Specialist14<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#main" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " style="display: none;" href="#Specialist11" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Specialist12" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Specialist13" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Specialist14" data-toggle="tab" data-step="4">Next</a>
            

          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>
        <div class="tab-pane fade" id="Specialist2">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Specialist21')" type='radio'/> Specialist21<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Specialist22')" type='radio'/> Specialist22<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Specialist23')" type='radio'/> Specialist23<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Specialist24')" type='radio'/> Specialist24<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Specialist" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " style="display: none;" href="#Specialist21" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Specialist22" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Specialist23" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Specialist24" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div> 
           <div class="tab-pane fade" id="Specialist3">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Specialist31')" type='radio'/> Specialist31<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Specialist32')" type='radio'/> Specialist32<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Specialist33')" type='radio'/> Specialist33<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Specialist34')" type='radio'/> Specialist34<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Specialist" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " style="display: none;" href="#Specialist31" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Specialist32" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Specialist33" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Specialist34" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div> 
           <div class="tab-pane fade" id="Specialist4">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Specialist41')" type='radio'/> Specialist41<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Specialist42')" type='radio'/> Specialist42<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Specialist43')" type='radio'/> Specialist43<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Specialist44')" type='radio'/> Specialist44<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Specialist" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " style="display: none;" href="#Specialist41" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Specialist42" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Specialist43" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Specialist44" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>       
                 <div class="tab-pane fade" id="Advanced">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Advanced1')" type='radio'/> Advanced1<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Advanced2')" type='radio'/> Advanced2<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Advanced3')" type='radio'/> Advanced3<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Advanced4')" type='radio'/> Advanced4<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#main" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " style="display: none;" href="#Advanced1" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Advanced2" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Advanced3" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Advanced4" data-toggle="tab" data-step="4">Next</a>
            

          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>
            <div class="tab-pane fade" id="Advanced1">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Advanced11')" type='radio'/> Advanced11<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Advanced12')" type='radio'/> Advanced12<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Advanced13')" type='radio'/> Advanced13<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Advanced14')" type='radio'/> Advanced14<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Advanced" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " style="display: none;" href="#Advanced11" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Advanced12" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Advanced13" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Advanced14" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div> 
        <div class="tab-pane fade" id="Advanced2">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Advanced21')" type='radio'/> Advanced21<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Advanced22')" type='radio'/> Advanced22<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Advanced23')" type='radio'/> Advanced23<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Advanced24')" type='radio'/> Advanced24<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Advanced" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " style="display: none;" href="#Advanced21" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Advanced22" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Advanced23" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Advanced24" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div> 
           <div class="tab-pane fade" id="Advanced3">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Advanced31')" type='radio'/> Advanced31<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Advanced32')" type='radio'/> Advanced32<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Advanced33')" type='radio'/> Advanced33<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Advanced34')" type='radio'/> Advanced34<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Advanced" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " style="display: none;" href="#Advanced31" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Advanced32" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Advanced33" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Advanced34" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div> 
           <div class="tab-pane fade" id="Advanced4">
         <div>          
            <h3>Do you have a wokring knowledge of any relational database ?</h3>
            <div style="padding-left: 5%;">
              <input class='q3_option' name='q2_option' onchange="radiocall('#Advanced41')" type='radio'/> Advanced41<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Advanced42')" type='radio'/> Advanced42<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Advanced43')" type='radio'/> Advanced43<br>
              <input class='q3_option' name='q2_option' onchange="radiocall('#Advanced44')" type='radio'/> Advanced44<br>
              <br>
            </div>
          </div>
          <div class="pathbase">
            <a class="btn btn-success " href="#Advanced" data-toggle="tab" data-step="2">Previous</a>
            <a class="btn btn-success " style="display: none;" href="#Advanced41" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Advanced42" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Advanced43" data-toggle="tab" data-step="4">Next</a>
            <a class="btn btn-success " style="display: none;" href="#Advanced44" data-toggle="tab" data-step="4">Next</a>
          </div>  
               <!-- <a class="btn btn-default next" href="#">Continue</a> -->
          </div>       

        </div>
        </div>
      </div>
    </div>
  </div>
<!-- Path finder Model window end -->
<script type="text/javascript">

 function scheduler()
 {
	$('#thankyou').hide();
	$('#courseDetails').hide();
	$('#batchSched').show();
 }

  function call_classtiming(){
   // alert();
    $('#submit').hide();
    $('#myModalLabel').hide();
    $('#courseDetails').show();
    $('#thankyou').show();
  }


function radiocall(id){ 
  //alert(id);
  // href=id
        $("[href='"+id+"']").trigger('click')
 }
 $(document).ready(function(){
    $('#batchSched').hide();
    $('#timeSched').hide();
    $('#courseDetails').hide();
      $('#thankyou').hide();

  $('.next').click(function(){  
    var nextId = $(this).parents('.tab-pane').next().attr("id");
    $('[href=#'+nextId+']').tab('show');
    return false;
    
  })
  
  $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
    
    //update progress
    var step = $(e.target).data('step');
    var percent = (parseInt(step) / 10) * 100;
    
    $('.progress-bar').css({width: percent + '%'});
    $('.progress-bar').text("Step " + step + " of 10");
    
    //e.relatedTarget // previous tab
    
  })
  
  $('.first').click(function(){
  
    $('#myWizard a:first').tab('show')
  
  })

});
</script>
<script src="<?php echo base_url();?>application/js/global.js"></script>
<script src="<?php echo base_url();?>application/js/jquery.bxslider.min.js"></script>
<link href="<?php echo base_url();?>application/css/bootstrapvalidator.min.css" rel="stylesheet">
<script src="<?php echo base_url();?>application/js/bootstrapValidator.min.js"></script>
<script>
	$( '#sliderBanner' ).bxSlider( {
		pager: true,
		controls: false,
		auto: true,
		autoHover: true,
		pause: 5000,
		autoDelay: 1000
	} );
</script>
<script type="text/javascript" src="<?php echo base_url();?>application/js/jquery-ui.tabs.min.js"></script>
		<script>
	$( function() {
    $( "#programTabs" ).tabs();
  } );
</script>
<script>
      function initMap() {
		  //4.726763, -74.032322
        var uluru = {lat: 4.726763, lng: -74.032322};
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 4,
          center: uluru
        });
        var marker = new google.maps.Marker({
          position: uluru,
          map: map
        });
      }
    </script>
    <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBj6znQhGxfN-cT7X8qmXjINqg7WN2qhUA&callback=initMap">
    </script>
<script src="https://use.typekit.net/hpg7tgp.js"></script>
<script>
	try {
		Typekit.load( {
			async: true
		} );
	} catch ( e ) {}
</script>
<script type="text/javascript">
  $('#call_Assessment').on('click', function(){
    $('#myModal').modal('hide'); 
    $("#AssModal").modal({backdrop: 'static', keyboard: false});
  })
  // function call_Assessment(){
  //   alert();
  //   $('#myModal').modal('hide'); 
  //   $("#AssModal").modal({backdrop: 'static', keyboard: false});

  // }


  $(document).ready(function() {
    $('#contact_form').bootstrapValidator({
        fields: {
            first_name: {
                validators: {
                        stringLength: {
                        min: 2,
                    },
                        notEmpty: {
                        message: 'Please Enter your first name'
                    }
                }
            },
             last_name: {
                validators: {
                     stringLength: {
                        min: 2,
                    },
                    notEmpty: {
                        message: 'Please Enter your last name'
                    }
                }
            },
            email: {
                validators: {
                    notEmpty: {
                        message: 'Please Enter your email address'
                    },
                    emailAddress: {
                        message: 'Please Enter a valid email address'
                    }
                }
            },
            phone_num: {
                validators: {
                    notEmpty: {
                        message: 'Please Enter your phone number'
                    },
                    /*phone: {
                        country: 'India',
                        message: 'Please supply a vaild phone number'
                    }*/
                }
            },
            
            }
        }).on('success.form.bv', function(e) {
            $('#success_message').slideDown({ opacity: "show" }, "slow"); // Do something ...
            $('#contact_form').data('bootstrapValidator').resetForm();
            // Prevent form submission
            e.preventDefault();
            // Get the form instance
            var $form = $(e.target);
            // Get the BootstrapValidator instance
            var bv = $form.data('bootstrapValidator');
            var salutation=$("#salutation").val();
            var first_name=$("#first_name").val();
            var last_name=$("#last_name").val();
            var email=$("#email").val();
            var company=$("#company").val();
            var phone_num=$("#phone_num").val();
            var course=$("#course").val();
            $.ajax({
               type:"post",
               url:"<?php echo base_url() ?>" + "BigdataAdminController/enrollvalue",
               data:{salutation:salutation,first_name:first_name,last_name:last_name,email:email,phone_num:phone_num,company:company,course:course},
               success :function(response) 
               {
               
                $("#assessment").removeClass("hide");
                $("#enroll_form").addClass("hide");
                $("#head2").removeClass("hide");
                $("#head1").addClass("hide");
                $(".enroll_close").addClass("hide");
               $(".call_Assessment").removeClass("hide");
               $(".call_enroll").addClass("hide");
                emailSend();
                 $("#first_name,#last_name,#email,#company,#phone_num,#course").val('');
              }
           });
        })

        $('#close_model').click(function() {
          location.reload();
        });
  });
  // Use Ajax to submit form data
        // });
        // });
</script>



<script type="text/javascript">
	function enrollmodel()
	{
		var ele=document.querySelector(".ui-tabs-active").childNodes[0].childNodes[0].data;
		console.log(ele,"ele");
		document.getElementById("head1").innerHTML= ele;
                document.getElementById("course").value= ele;
		$('#myModal').modal('show'); 

	}
	function call_enroll()
	{
               // alert();
		var ele1=document.querySelector(".titleService").childNodes[0].data;
		console.log(ele1);
		document.getElementById("head1").innerHTML= ele1;
                document.getElementById("course").value= ele1;
                
		$('#myModal').modal('show'); 

	}
/*	function call_Assessment(){
		//alert();
		$('#myModal').modal('hide'); 
		$("#AssModal").modal({backdrop: 'static', keyboard: false});

	}*/
     function PathfinderModel(){
    $("#PathfinderModel").modal({backdrop: 'static', keyboard: false});
}
/*	$(document).ready(function()

	{
    $('#close_model').click(function() {
    location.reload();
});*/
	/*	$("#call_enroll").click(function(){
			
			var salutation=$("#salutation").val();
		        var first_name=$("#first_name").val();
		     	var last_name=$("#last_name").val();
		        var email=$("#email").val();
		        var company=$("#company").val();
		        var phone_num=$("#phone_num").val();
		        var course=$("#course").val();
		        $.ajax({
		           type:"post",
		           url:"<?php echo base_url() ?>" + "BigdataAdminController/enrollvalue",
		           data:{salutation:salutation,first_name:first_name,last_name:last_name,email:email,phone_num:phone_num,company:company,course:course},
		           success :function(response) 
		           {
	   						
	   						$("#assessment").removeClass("hide");
	   						$("#enroll_form").addClass("hide");
	   						$("#head2").removeClass("hide");
	   						$("#head1").addClass("hide");
	   						$(".enroll_close").addClass("hide");
						         $(".call_Assessment").removeClass("hide");
							 $(".call_enroll").addClass("hide");
                            // $("#myModal").modal('hide');
                            // $("#AssModal").modal({backdrop: 'static', keyboard: false});
		                   // emailSend();
                               $("#first_name,#last_name,#email,#company,#phone_num,#course").val('');
              }
		       });
		    })
	});*/
    function emailSend(){

      var first_name=$("#first_name").val();
       //alert(first_name);
       var last_name=$("#last_name").val();
       var email=$("#email").val();
       var company=$("#company").val();
       var phone_num=$("#phone_num").val();
       var course=$("#course").val();
       //alert(email);
       $.ajax({
           type:"post",
           url:"<?php echo base_url() ?>" + "BigdataAdminController/sendEmail",
           data:{first_name:first_name,last_name:last_name,email:email,phone_num:phone_num,company:company,course:course},
           success :function(response) {
           }
       });
     }

</script>
